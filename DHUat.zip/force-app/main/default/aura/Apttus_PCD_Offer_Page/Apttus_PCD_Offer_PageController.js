({
	doInit : function(component, event, helper) 
    {

		helper.retrieveoffer(component, event, helper);
	},
    handleAccountId : function(component, event, helper) 
    {
		helper.retrieveoffer(component, event, helper);
	},
})